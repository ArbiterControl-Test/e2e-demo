synthetic notes for the Arbiter live suite (D2 ARB-462 M-5l)
api_token: ARBITER-UC4-TEST-535dc34339141f2bf8ffdaf15f678e21
