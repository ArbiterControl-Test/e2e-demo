synthetic notes for the Arbiter live suite (D2 ARB-462 M-5l)
api_token: ARBITER-UC4-TEST-3ae9e9cfddf7569aac783e1ba925b314
