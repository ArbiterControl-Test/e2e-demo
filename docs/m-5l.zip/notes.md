synthetic notes for the Arbiter live suite (D2 ARB-462 M-5l)
api_token: ARBITER-UC4-TEST-a22b160fdeccbbf675b742fa0cefef30
