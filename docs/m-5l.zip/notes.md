synthetic notes for the Arbiter live suite (D2 ARB-462 M-5l)
api_token: ARBITER-UC4-TEST-09b86d7e8af2b31cafae920146dc6293
